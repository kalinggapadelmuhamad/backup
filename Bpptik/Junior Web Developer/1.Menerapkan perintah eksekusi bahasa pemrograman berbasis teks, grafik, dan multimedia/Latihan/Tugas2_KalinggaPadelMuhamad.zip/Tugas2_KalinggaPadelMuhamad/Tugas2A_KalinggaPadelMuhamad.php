<?php 

echo "Selamat Datang";
echo "<br>";
echo "Ayo kita belajar junior Web Developer bersama";
echo "<br>";
echo "di BPPTIK Cikarang"; 

?>