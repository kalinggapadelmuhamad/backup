# Program Menghitung rumus Persegi,Lingkaran dan Segitiga

Program ini di buat untuk membantu seseorang dalam menghitung rumus dalam jumlah 
angka yang besar

## Requirements

Php >= 5.6

## Instalation

Download
[Program](http://kalinggafadelmuhamad.github.io)

Unzip Folder Program
Move to c:\xampp\htdocs

## Usage 

Open c:\xampp\htdocs\PROGRAM\index.php

Contoh Penggunaan
Luas Lingkaran 		 : $var = new Rumus();
				       $var->luasLingkaran(20);

Luas Segitiga 		 : $var = new Rumus();
				 	   $var->luasSegitiga(20, 20);

Luas Persegi Panjang : $var = new Rumus();
				       $var->luasPersegi(20);

## Lisence 
Kalingga Padel Muhamad