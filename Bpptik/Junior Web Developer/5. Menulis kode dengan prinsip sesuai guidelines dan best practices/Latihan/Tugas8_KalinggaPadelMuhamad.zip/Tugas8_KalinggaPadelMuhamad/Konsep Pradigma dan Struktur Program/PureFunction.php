<?php 

	function ucapkanSalam($salam){
		echo "Hallo Selamat ". $salam;
	} 

	ucapkanSalam("Pagi");

?>