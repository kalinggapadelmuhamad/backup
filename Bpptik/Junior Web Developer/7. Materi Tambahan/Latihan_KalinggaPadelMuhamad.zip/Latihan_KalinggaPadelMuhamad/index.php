<!DOCTYPE html>
<html>
<head>
	<title>Registrasi Pasien Rawat Jalan</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css">
</head>
	<?php 
     
     //memanggil koneksi DB.
	 include 'app/config/config.php';
	 //memanggil class crud.
	 include 'app/models/select.php';
     
     //cek parameter key
	 if (isset($_GET['key'])) {
	  	
	  	//cek isi key
	  	switch ($_GET['key']) {

	  		case 'success':
	  			echo "<body onload='success()'>";
	  			break;
	  		
	  		case 'error':
	  			echo "<body onload='error()'>";
	  			break;

	  		default:
	  			echo "<body>";
	  			break;
	  	}

	  } 

	?>
    
    <center>
	<h1>Registrai Rawat Jalan</h1>
	<form method="POST" action="app/models/helper.php">
		<table>
			<tr>
				<td>Nama Pasien</td>
				<td>:</td>
				<td><input type="text" name="nPasien" placeholder="Masukan Nama" maxlength="25" required=""></td>
			</tr>
			<tr>
				<td>Nomor Rekam Medis</td>
				<td>:</td>
				<td><input type="text" name="nRekammedis" placeholder="ASN12X"  maxlength="6" required=""></td>
			</tr>
			<tr>
				<td>Poli</td>
				<td>:</td>
				<td>
					<select name="poli" required="">
						<option value="Umum">Umum</option>
						<option value="THT">THT</option>
						<option value="Dalam">Dalam</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Tanggal Pemeriksaan</td>
				<td>:</td>
				<td><input type="date" name="tPeriksa" required=""></td>
			</tr>
			<tr>
				<td>Jenis Pembayaran</td>
				<td>:</td>
				<td>
					<input type="radio" name="jPembayaran" required="" value="Umum"><label>UMUM</label>
					<input type="radio" name="jPembayaran" required="" value="Bpjs"><label>BPJS</label>
				</td>
			</tr>
			<tr>
				<td><input type="submit" name="daftar" value="Daftar"></td>
			</tr>
		</table>
	</form>

	<table border="1">
		<tr>
			<td>No</td>
			<td>Nama Pasien</td>
			<td>Nomor Rekam Medis</td>
			<td>Poli</td>
			<td>Tanggal Pemeriksaan</td>
			<td>Jenis Pembayaran</td>
		</tr>
		<br>
		<?php
        
        //membuat no urut pasien
		$i = 1; 
          
        //membuat object dari class CRUD
        $sDataPasien = new CRUD();

        //ekseskusi selec data
        $result = $sDataPasien->sData("tbrawatjalan", $conn);
        
        //looping semua isi table
        while ($fResulut = $result->fetch_array()) {
        	echo "<tr>";
        	echo "<td>".$i++."</td>";
        	echo "<td>{$fResulut['nPasien']}</td>";
        	echo "<td>{$fResulut['nRekammedis']}</td>";
        	echo "<td>{$fResulut['poli']}</td>";
        	echo "<td>{$fResulut['tPeriksa']}</td>";
        	echo "<td>{$fResulut['jBayar']}</td>";
        	echo "</tr>";
        }
	

		 ?>
	</table>
	</center>

<script type="text/javascript" src="assets/js/sw.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
</body>
</html>