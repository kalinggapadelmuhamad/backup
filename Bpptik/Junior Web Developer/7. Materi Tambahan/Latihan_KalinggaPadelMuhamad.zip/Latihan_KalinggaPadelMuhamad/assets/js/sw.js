function success(){
    
    Swal({

    	title: 'success', 
    	text: 'Berhasil Menambahkan Data Pasien', 
    	type: 'success', 
    	timer: 3000, 
    	showConfirmButton: true

    });
  }

  function error(){
    
    Swal({

    	title: 'error', 
    	text: 'Gagal Menambahkan Data Pasien', 
    	type: 'error', 
    	timer: 3000, 
    	showConfirmButton: true

    });
  }
