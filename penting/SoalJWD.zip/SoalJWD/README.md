# Aplikasi Hitung Total Nilai siswa 

Aplikasi ini di gunakan untuk menghitung total nilai siswa dari 3 mata pelajaran

## Hirarki directory

/SoalJWD
	/data
		/* data.json
	/assets
		/css
			/* bootsrap.css
	index.php
	Readme.md

## Requirement 

php 7.3.15
Bootsrap v4.0.0-alpha.6

## Instalation

Download[Program]
Unzip[Program]
Move [Program] to C/xampp/htdocs/

## Usage 

Run Apache on XAMPP/LAMPP dll
In Browser type adrres localhost/[Program]

## lisence 

Kalingga Padel Muhamad SoalJWD3
