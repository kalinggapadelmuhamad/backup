<?php 

phpinfo()
 ?>